package com.example.samyuck;


import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class FriendListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private FriendAdapter adapter;
    private List<UserAccount> friendList = new ArrayList<>();
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_list);

        recyclerView = findViewById(R.id.recyclerViewFriends);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new FriendAdapter(friendList, uid -> deleteFriend(uid));
        recyclerView.setAdapter(adapter);

        loadFriends();
    }

    private void loadFriends() {
        db.collection("users").document(currentUser.getUid())
                .get()
                .addOnSuccessListener(doc -> {
                    List<String> friendUids = (List<String>) doc.get("friends");
                    if (friendUids == null) return;

                    for (String uid : friendUids) {
                        db.collection("users").document(uid).get()
                                .addOnSuccessListener(friendDoc -> {
                                    UserAccount user = friendDoc.toObject(UserAccount.class);
                                    friendList.add(user);
                                    adapter.notifyDataSetChanged();
                                });
                    }
                });
    }

    private void deleteFriend(String friendUid) {
        db.collection("users").document(currentUser.getUid())
                .update("friends", FieldValue.arrayRemove(friendUid));

        db.collection("users").document(friendUid)
                .update("friends", FieldValue.arrayRemove(currentUser.getUid()))
                .addOnSuccessListener(aVoid ->
                        Toast.makeText(this, "친구 삭제됨", Toast.LENGTH_SHORT).show());
    }
}
