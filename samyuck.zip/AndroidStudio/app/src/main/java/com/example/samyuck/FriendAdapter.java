package com.example.samyuck;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.function.Consumer;

public class FriendAdapter extends RecyclerView.Adapter<FriendAdapter.ViewHolder> {
    private List<UserAccount> friends;
    private Consumer<String> onDelete;

    public FriendAdapter(List<UserAccount> friends, Consumer<String> onDelete) {
        this.friends = friends;
        this.onDelete = onDelete;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameView, emailView;
        Button btnDelete;

        public ViewHolder(View view) {
            super(view);
            nameView = view.findViewById(R.id.textName);
            emailView = view.findViewById(R.id.textEmail);
            btnDelete = view.findViewById(R.id.btnDelete);
        }
    }

    @Override
    public FriendAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_item_friend, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        UserAccount user = friends.get(position);
        holder.nameView.setText(user.getName());
        holder.emailView.setText(user.getEmailId());

        holder.btnDelete.setOnClickListener(v -> onDelete.accept(user.getIdToken()));
    }

    @Override
    public int getItemCount() {
        return friends.size();
    }
}
