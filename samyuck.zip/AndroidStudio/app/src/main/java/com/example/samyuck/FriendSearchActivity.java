package com.example.samyuck;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;

import java.util.HashMap;
import java.util.Map;

public class FriendSearchActivity extends AppCompatActivity {

    private EditText emailInput;
    private Button btnSearch;
    private DatabaseReference databaseRef;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_search);

        emailInput = findViewById(R.id.editTextEmail);
        btnSearch = findViewById(R.id.buttonSendRequest);

        databaseRef = FirebaseDatabase.getInstance().getReference("users");
        currentUser = FirebaseAuth.getInstance().getCurrentUser();

        btnSearch.setOnClickListener(v -> {
            String email = emailInput.getText().toString().trim().toLowerCase();
            searchUserByEmail(email);
        });
    }

    private void searchUserByEmail(String email) {
        databaseRef.orderByChild("emailId").equalTo(email)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            // 이메일에 해당하는 유저 찾음
                            for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                                String toUid = userSnapshot.getKey();

                                if (toUid.equals(currentUser.getUid())) {
                                    Toast.makeText(FriendSearchActivity.this, "자기 자신에게는 요청할 수 없습니다.", Toast.LENGTH_SHORT).show();
                                    return;
                                }

                                // 친구 요청 보내는 로직 (Realtime DB에 맞게 구현 필요)
                                sendFriendRequest(toUid);
                                break;
                            }
                        } else {
                            Toast.makeText(FriendSearchActivity.this, "해당 이메일의 사용자를 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        Toast.makeText(FriendSearchActivity.this, "검색 중 오류가 발생했습니다.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void sendFriendRequest(String toUid) {
        DatabaseReference friendRequestsRef = FirebaseDatabase.getInstance().getReference("friend_requests");

        String requestId = friendRequestsRef.push().getKey();
        Map<String, Object> request = new HashMap<>();
        request.put("from", currentUser.getUid());
        request.put("to", toUid);
        request.put("status", "pending");

        friendRequestsRef.child(requestId).setValue(request)
                .addOnSuccessListener(aVoid ->
                        Toast.makeText(FriendSearchActivity.this, "요청이 전송되었습니다!", Toast.LENGTH_SHORT).show()
                )
                .addOnFailureListener(e ->
                        Toast.makeText(FriendSearchActivity.this, "요청 전송 실패", Toast.LENGTH_SHORT).show()
                );
    }
}
