package com.example.samyuck;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private CalendarAdapter calendarAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupCalendar();

        TextView friendView = findViewById(R.id.friendview);
        friendView.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, FriendSearchActivity.class);
            startActivity(intent);
        });
    }

    private void setupCalendar() {
        RecyclerView recyclerView = findViewById(R.id.calendarGrid);
        calendarAdapter = new CalendarAdapter();

        recyclerView.setLayoutManager(new GridLayoutManager(this, 7));
        recyclerView.setAdapter(calendarAdapter);

        Calendar calendar = Calendar.getInstance();
        calendarAdapter.setCalendarDays(
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH)
        );
    }
}
