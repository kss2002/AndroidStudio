package com.example.samyuck;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CalendarAdapter extends RecyclerView.Adapter<CalendarAdapter.CalendarViewHolder> {

    private List<CalendarDay> days = new ArrayList<>();
    private int selectedPosition = -1;

    public static class CalendarDay {
        public Date date;
        public int dayOfMonth;
        public boolean isCurrentMonth;

        public CalendarDay(Date date, int dayOfMonth, boolean isCurrentMonth) {
            this.date = date;
            this.dayOfMonth = dayOfMonth;
            this.isCurrentMonth = isCurrentMonth;
        }
    }

    public static class CalendarViewHolder extends RecyclerView.ViewHolder {
        public TextView dayText;

        public CalendarViewHolder(View itemView) {
            super(itemView);
            dayText = itemView.findViewById(R.id.dayText);
        }
    }

    @NonNull
    @Override
    public CalendarViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_calendar_day, parent, false);
        return new CalendarViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CalendarViewHolder holder, int position) {
        CalendarDay day = days.get(position);
        holder.dayText.setText(String.valueOf(day.dayOfMonth));
        holder.dayText.setSelected(position == selectedPosition);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(day.date);
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);

        if (!day.isCurrentMonth) {
            holder.dayText.setTextColor(Color.LTGRAY);
        } else if (position == selectedPosition) {
            holder.dayText.setTextColor(Color.WHITE);
        } else if (dayOfWeek == Calendar.SUNDAY) {
            holder.dayText.setTextColor(Color.RED);
        } else if (dayOfWeek == Calendar.SATURDAY) {
            holder.dayText.setTextColor(Color.BLUE);
        } else {
            holder.dayText.setTextColor(Color.BLACK);
        }

        holder.itemView.setOnClickListener(v -> {
            int oldPosition = selectedPosition;
            selectedPosition = holder.getAdapterPosition();
            notifyItemChanged(oldPosition);
            notifyItemChanged(selectedPosition);
        });
    }

    @Override
    public int getItemCount() {
        return days.size();
    }

    public void setCalendarDays(int year, int month) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, 1);

        List<CalendarDay> newDays = new ArrayList<>();

        // 이전 달의 날짜 추가
        int firstDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        calendar.add(Calendar.DAY_OF_MONTH, -(firstDayOfWeek - 1));
        for (int i = 0; i < firstDayOfWeek - 1; i++) {
            newDays.add(new CalendarDay(calendar.getTime(), calendar.get(Calendar.DAY_OF_MONTH), false));
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }

        // 현재 달의 날짜 추가
        calendar.set(year, month, 1);
        int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = 1; i <= daysInMonth; i++) {
            newDays.add(new CalendarDay(calendar.getTime(), i, true));
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }

        // 다음 달의 날짜 추가
        int remainingDays = 42 - newDays.size(); // 6행 x 7열 = 42칸
        for (int i = 0; i < remainingDays; i++) {
            newDays.add(new CalendarDay(calendar.getTime(), calendar.get(Calendar.DAY_OF_MONTH), false));
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }

        this.days = newDays;
        notifyDataSetChanged();
    }
}
